package enumeraciones;

public enum Dia {
    DOMINGO,LUNES,MARTES,MIERCOLES,JUEVES,VIERNES,SABADO
}
