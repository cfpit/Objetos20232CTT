package comparacionObjetos;

import java.util.Objects;

public class Auto {
    private String marca;
    private int nroMotor;

    public Auto() {}

    public Auto(String marca, int nroMotor) {
        this.setMarca(marca);
        this.setNroMotor(nroMotor);
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public int getNroMotor() {
        return nroMotor;
    }

    public void setNroMotor(int nroMotor) {
        this.nroMotor = nroMotor;
    }

    @Override
    public String toString() {
        return "Auto{" + "marca=" + marca + ", nroMotor=" + nroMotor + '}';
    }
    
    //redefino equals y hashCode

//    @Override
//    public int hashCode() {
////        int hash = 3;
////        hash = 73 * hash + Objects.hashCode(this.marca);
////        hash = 73 * hash + this.nroMotor;
////        return hash;
//
//        return Objects.hashCode(nroMotor);
//    }

//    @Override
//    public boolean equals(Object obj) {
////        if (this == obj) {
////            return true;
////        }
////        if (obj == null) {
////            return false;
////        }
////        if (getClass() != obj.getClass()) {
////            return false;
////        }
////        final Auto other = (Auto) obj;
////        if (this.nroMotor != other.nroMotor) {
////            return false;
////        }
////        return Objects.equals(this.marca, other.marca);
//
//        //casteo
//         Auto a =(Auto)obj;
//         
//         if (this.getNroMotor() == a.getNroMotor() && this.getMarca().equals(a.getMarca())) 
//         {
//             return true;
//         } 
//         else 
//         {
//             return false;
//         }
//    }

    @Override
    public int hashCode() {
        
        int hash = 7;
        hash = 71 * hash + Objects.hashCode(this.marca);
        hash = 71 * hash + this.nroMotor;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Auto other = (Auto) obj;
        if (this.nroMotor != other.nroMotor) {
            return false;
        }
        return Objects.equals(this.marca, other.marca);
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
