

package herencia;


public class Tractor {

}
