

package base3;

import java.sql.SQLException;
import java.util.Scanner;


public class Test {
    public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        
//            Alumno.consultarTodos();
//            Alumno.consultarUno("Juan");


//            Scanner lector = new Scanner(System.in);
//            
//            System.out.println("ingrese el nombre: ");
//            String nombre = lector.next();
//            
//            System.out.println("ingrese la edad: ");
//            int edad = lector.nextInt();
//            
//            Alumno a = new Alumno(nombre, edad);
//            Alumno.insertar(a);
//            Alumno.consultarTodos();
            
            
            
            
            
            
            
            Scanner lector = new Scanner(System.in);
            
            System.out.println("ingrese el nombre a elimnar: ");
            String nombre = lector.next();
            
            Alumno.eliminar(nombre);
            Alumno.consultarTodos();
            
            
            
            
            
            
        
    }
}
