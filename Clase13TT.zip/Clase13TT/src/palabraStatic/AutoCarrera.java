package palabraStatic;

public class AutoCarrera extends Auto{



}
    