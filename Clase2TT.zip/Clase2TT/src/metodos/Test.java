package metodos;

import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        //creo dos objetos de la clase CajaDeAhorro
        CajaDeAhorro cda = new CajaDeAhorro();
        CajaDeAhorro cda2 = new CajaDeAhorro();
        
        //le doy un estado a los objetos
        cda.saldo = 2500;
        cda.moneda = "U$s";
        
        cda2.saldo = 700;
        cda2.moneda = "$";
        
        Scanner lector = new Scanner(System.in);
        
        System.out.println("Ingrese el monto a depositar: ");
        cda.depositar(lector.nextInt());
        
        System.out.println("Ingrese el monto a extraer: ");
        System.out.println(cda.extraer(lector.nextInt()));
        
        //comportamiento
        cda.consultarSaldo();
        System.out.println("--------------------");
        cda2.consultarSaldo();
        
        
        
        
        
        
    }
}
