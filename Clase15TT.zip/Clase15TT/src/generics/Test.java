package generics;

public class Test {
    public static void main(String[] args) {
//        Generica<String> g = new Generica<>();
//        
//        g.agregar("Juan");
//        g.agregar("Maria");
//        g.agregar("Luis");
//        g.agregar("Carlos");
//        
//        System.out.println("Contenido: " + g.lista);
//        
//        //recorro la coleccion mediante delegados
//        for (int i = 0; i < g.tamaño(); i++) {
//            System.out.println(g.obtener(i));
//        }
//        
//        g.eliminar(0);
//        
//        System.out.println("Nuevo contenido: " + g.lista);
        
        
        
        
        
        
        Generica<Persona> g = new Generica<>();
        
        g.agregar(new Persona("Juan", 25));
        g.agregar(new Persona("Maria", 30));
        g.agregar(new Persona("Luis", 50));
        g.agregar(new Persona("Carlos", 40));
        
        
        System.out.println("Contenido: " + g.lista);
        
        //recorro la coleccion mediante delegados
        for (int i = 0; i < g.tamaño(); i++) {
            System.out.println(g.obtener(i));
        }
        
        g.eliminar(0);
        
        System.out.println("Nuevo contenido: " + g.lista);
    }
}



