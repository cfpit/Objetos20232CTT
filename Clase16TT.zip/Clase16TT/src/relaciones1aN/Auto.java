package relaciones1aN;

public class Auto {
    private String marca;
    private String color;
    
    public Auto() {}

    public Auto(String marca, String color) {
        this.setMarca(marca);
        this.setColor(color);
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    @Override
    public String toString() {
        return "Auto{" + "marca=" + marca + ", color=" + color + '}';
    }
}
