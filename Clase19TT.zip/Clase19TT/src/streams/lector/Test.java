package streams.lector;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Test {
    public static void main(String[] args) throws FileNotFoundException, IOException   {
        
        //FileReader--> lee de a caracteres un archivo de texto
        //BufferedReader--> lee de a lineas enteras un archivo de texto
        //El BufferedReader acumula los caracteres enviados por el FileReader
        //hasta formar una linea de texto entera.
        //path --> ruta de un archivo
        
//        creo un objeto File q contiene la ruta del archivo a leer
//        File archivo = new File("src\\streams\\lector\\archivo.txt");
        File archivo = new File("src/streams/lector/archivo.txt");
        
        //creo el stream de lectura
        BufferedReader lector = new BufferedReader(new FileReader(archivo));
        
        //algoritmo de lectura
        
        //variables auxiliares
        String lineaLeida;//guarda una linea entera del BufferedReader(el stream)
        boolean eof = false;//eof = end of file --> indicador o flag de fin de archivo
        
        //bucle de lectura
        //mientras no sea fin de archivo...
        while (!eof) 
        {
            //leo una linea entera del stream y la guardo en la variable lineaLeida
            lineaLeida = lector.readLine();
            
            //si la linea leida no es nula, entonces...
            if (lineaLeida != null) 
            {
                //...mostramos el contenido del archivo por consola
                System.out.println(lineaLeida);
            }
            else
            {
                //cambio el estado del flag, indicando que termino el archivo
                eof = true;
            }
        }
        
        //cierro el stream por seguridad(anti-malware)
        lector.close();
    
    }
}
