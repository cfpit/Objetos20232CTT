
package metodos;

/**
 *
 * @author Aula 7 - Docente
 */
public class CajaDeAhorro {
    //atributos
    public int saldo;
    public String moneda;
    
    //constructor
    public CajaDeAhorro() {}
    
    //metodos
    public String consultarSaldo() {
        return "saldo = " + this.saldo;
    }
    
    public void depositar(int monto) {
        this.saldo += monto;
    }
    
    public String extraer(int monto) {
        if (monto > this.saldo) 
        {
            return "Fondos insuficientes";
        } 
        else 
        {
            this.saldo -= monto;
            return "Extraccion OK";
        }
    }
    
    

}
