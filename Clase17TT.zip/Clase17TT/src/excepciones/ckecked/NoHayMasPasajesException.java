

package excepciones.ckecked;


public class NoHayMasPasajesException extends Exception{
    private String vuelo;
    private int asientos;

    public NoHayMasPasajesException() {}

    public NoHayMasPasajesException(String vuelo, int asientos) {
        this.setVuelo(vuelo);
        this.setAsientos(asientos);
    }

    public String getVuelo() {
        return vuelo;
    }

    public void setVuelo(String vuelo) {
        this.vuelo = vuelo;
    }

    public int getAsientos() {
        return asientos;
    }

    public void setAsientos(int asientos) {
        this.asientos = asientos;
    }

    @Override
    public String toString() {
        return "NoHayMasPasajesException{" + "vuelo=" + vuelo + ", asientos=" + asientos + '}';
    }
    
    public void mostrarMensaje() {
        System.out.println("El vuelo " + this.vuelo + " no tiene " +
                this.asientos + " asientos disponibles");
    }
}
