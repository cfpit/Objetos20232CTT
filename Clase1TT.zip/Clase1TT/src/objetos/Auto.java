package objetos;

public class Auto {
    //atributos
    public String marca;
    public String color;
    public int velocidad;
    
    
    //metodo constructor
    //constructor vacio o por defecto
    public Auto() {}
    
    
    
    
    
}
