package base;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class Conexion {
    public static Connection obtenerConexion() throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        String driver = "com.mysql.cj.jdbc.Driver";
        
        String conexion = "jdbc:mysql://127.0.0.1:3306/colegio";
        String usuario = "root";
        String clave = "";
        
        //creo un objeto de la clase Driver por API Reflection
        Class.forName(driver).newInstance();
        
        //retorno un objeto de tipo Connection que contiene
        //la info del servidor, credenciales y base a conectar
        return DriverManager.getConnection(conexion, usuario, clave);        
    }
}
