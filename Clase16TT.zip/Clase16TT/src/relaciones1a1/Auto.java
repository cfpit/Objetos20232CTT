package relaciones1a1;

public class Auto {
    private String marca;
    private Motor motor;

    public Auto() {}

    public Auto(String marca, Motor motor) {
        this.setMarca(marca);
        this.setMotor(motor);
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public Motor getMotor() {
        return motor;
    }

    public void setMotor(Motor motor) {
        this.motor = motor;
    }

    @Override
    public String toString() {
        return "marca=" + marca + ", motor=" + motor;
    }
}
