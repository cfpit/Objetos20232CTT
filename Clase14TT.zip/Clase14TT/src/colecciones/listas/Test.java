package colecciones.listas;

import java.util.ArrayList;
import java.util.Iterator;

public class Test {
    public static void main(String[] args) {
        //creo una coleccion de tipo lista
        ArrayList coleccion = new ArrayList();//no tipada
        ArrayList<Persona> coleccion2 = new ArrayList<>();//tipada
        
        //creo objetos de la clase Persona
        Persona p1 = new Persona("Juan", 25);
        Persona p2 = new Persona("Maria", 30);
        Persona p3 = new Persona("Luis", 40);
        Persona p4 = new Persona("Carlos", 20);
        
        //agrego los objetos a la coleccion
        coleccion2.add(p1);
        coleccion2.add(p2);
        coleccion2.add(p3);
        coleccion2.add(p4);
        
        System.out.println("Contenido: " + coleccion2);
        
        //agrego un objeto mas en la 3ra posicion de la coleccion
        Persona p5 = new Persona("Ana", 50);
        coleccion2.add(2, p5);
        
        //Elimino un objeto de la coleccion
        coleccion2.remove(3);
        
        System.out.println("Nuevo contenido: " + coleccion2);
        
        System.out.println("------------------------------------");
        
        System.out.println("Recorro con for");//forl
        for (int i = 0; i < coleccion2.size(); i++) 
        {
            Persona unaPersona = coleccion2.get(i);
            
            if (unaPersona.getEdad() > 28) 
            {
                System.out.println(unaPersona);
            }
        }
        
        System.out.println("Recorro con foreach");//fore
        for (Persona unaPersona : coleccion2) {
            if (unaPersona.getEdad() <= 25) 
            {
                System.out.println(unaPersona);
            }
        }
        
        System.out.println("Recorro con iterator");//whileit
        
        //creo un iterador para recorrer la coleccion
        Iterator it =  coleccion2.iterator();
        while (it.hasNext()) 
        {
            Persona unaPersona = (Persona)it.next();
            
            if (unaPersona.getEdad()>= 20 && unaPersona.getEdad() <= 30) 
            {
                System.out.println(unaPersona);
            }
        }
    }
}












