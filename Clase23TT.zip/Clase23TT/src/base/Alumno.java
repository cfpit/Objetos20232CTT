package base;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.PreparedStatement;

public class Alumno {

    private String nombre;
    private int edad;

    public Alumno() {
    }

    public Alumno(String nombre, int edad) {
        this.setNombre(nombre);
        this.setEdad(edad);
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    @Override
    public String toString() {
        return "nombre=" + nombre + ", edad=" + edad;
    }

    //metodos ABMC (CRUD)
    public static void consultarTodos() throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        //creo una conexion
        Connection unaConexion = Conexion.obtenerConexion();

        //armo la query
        String unaConsulta = "select * from alumnos";

        //creo una sentencia
        Statement unaSentencia = unaConexion.createStatement();

        //ejecuto la query y guardo el resultado
        ResultSet unResultado = unaSentencia.executeQuery(unaConsulta);

        //recorro el resultado y muestro el contenido
        while (unResultado.next()) {
            System.out.println("Nombre: " + unResultado.getString("nombre"));
            System.out.println("Edad: " + unResultado.getInt("edad"));
            System.out.println("------------------------------------");
        }

        //cierro la conexion
        unResultado.close();
        unaSentencia.close();
        unaConexion.close();

    }

    public static void consultarUno(String nombre) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        //creo una conexion
        Connection unaConexion = Conexion.obtenerConexion();

        //armo la query
        String unaConsulta = "select * from alumnos where nombre = '" + nombre + "'";

        //creo una sentencia
        Statement unaSentencia = unaConexion.createStatement();

        //ejecuto la query y guardo el resultado
        ResultSet unResultado = unaSentencia.executeQuery(unaConsulta);

        //recorro el resultado y muestro el contenido
        if (unResultado.next()) {
            System.out.println("Nombre: " + unResultado.getString("nombre"));
            System.out.println("Edad: " + unResultado.getInt("edad"));
            System.out.println("------------------------------------");
        }

        //cierro la conexion
        unResultado.close();
        unaSentencia.close();
        unaConexion.close();

    }

    public static void insercion(Alumno a) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        //creo una conexion
        Connection unaConexion = Conexion.obtenerConexion();

        //armo la sentencia
        String unaInsercion = "insert into alumnos(nombre, edad) values(?, ?)";

        //creo una sentencia
        PreparedStatement unaSentencia = unaConexion.prepareStatement(unaInsercion);

        //seteo los parametros a reemplazar en los ?
        unaSentencia.setString(1, a.getNombre());
        unaSentencia.setInt(2, a.getEdad());

        //ejecuto la sentencia
        unaSentencia.execute();

        System.out.println("Insercion correcta");

        //cierro la conexion
        unaSentencia.close();
        unaConexion.close();

    }
    
    
    public static void eliminacion(String nombre) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        //creo una conexion
        Connection unaConexion = Conexion.obtenerConexion();

        //armo la sentencia
        String unaEliminacion = "delete from alumnos where nombre = ?";

        //creo una sentencia
        PreparedStatement unaSentencia = unaConexion.prepareStatement(unaEliminacion);

        //seteo los parametros a reemplazar en los ?
        unaSentencia.setString(1, nombre);
        

        //ejecuto la sentencia
        unaSentencia.execute();

        System.out.println("Eliminacion correcta");

        //cierro la conexion
        unaSentencia.close();
        unaConexion.close();

    }

}
