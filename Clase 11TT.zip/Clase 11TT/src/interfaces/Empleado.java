package interfaces;

public interface Empleado {
    
    //contrato
//    public void fichar();
//    public void tomarLicencia();
//    public void darDeAlta();
//    public void darDeBaja();
    public void calcularSueldo();
}
