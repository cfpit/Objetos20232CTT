-- Consultas Relacionadas (JOINS)
-- listar el nombre de las editoriales y de los libros
-- publicados por ellas.

-- Tablas a relacionar: titles y publishers

-- Se relacionan por pub_id

-- Usar INNER JOIN --> devuelve aquellos registros
-- en los que hay coincidencias en los valores de
-- pub_id de ambas tablas
select 		t.title as libro,
			p.pub_name as editorial
from		publishers p
inner join	titles t 
on			p.pub_id = t.pub_id;

-- listar el nombre y apellido de los autores que
-- escribieron libros de psicologia.
select		concat(a.au_fname,' ',a.au_lname) as autor,
			t.type as categoria
from		authors a
inner join	titleauthor ta on a.au_id = ta.au_id
inner join	titles t on t.title_id = ta.title_id
where		t.type like '%psy%';

-- agregar a la ultima query, el nombre de la editorial
select		concat(a.au_fname,' ',a.au_lname) as autor,
			t.type as categoria,
            p.pub_name as editorial
from		authors a
inner join	titleauthor ta on a.au_id = ta.au_id
inner join	titles t on t.title_id = ta.title_id
inner join	publishers p on p.pub_id = t.pub_id
where		t.type like '%psy%';

-- listar los libros que no fueron vendidos
-- outer join (left o right)

-- Tablas a relacionar: titles y sales
-- Se relacionan por title_id
-- Tabla ppal: es aquella de la cual se quieren obtener datos
-- Tabla ppal: titles / tabla secundaria: sales
select	t.title as libro
		-- ,s.*
from	sales s right join titles t
on		s.title_id = t.title_id
where	s.stor_id is null;

-- listar las editoriales que no publicaron libros.
-- tabla ppal: publishers
select	p.pub_name editorial
		-- ,t.*
from	publishers p left join titles t
on		p.pub_id = t.pub_id
where	t.title_id is null;

/*
	SQL 
		--> DDL	: lenguaje de definicion de datos
			--> CREATE
            --> ALTER
            --> DROP
            --> operan sobre objetos: bases, tablas, vistas
		--> DML	: lenguaje de manipulacion de datos
			--> SELECT
            --> INSERT
            --> UPDATE
            --> DELETE
            --> operan sobre registros
*/

create database colegio;

use colegio;

create table alumnos(
	nombre varchar(20),
    edad int
);

insert into alumnos values
('Juan Perez',25),('Maria Garcia',30),('Luis Lopez',40),('Ana Gonzalez',45);

select * from alumnos;

update alumnos set edad = edad + 1 where nombre like '%perez%';
select * from alumnos;

delete from alumnos where nombre like '%luis%';
select * from alumnos;

alter table alumnos add column mail varchar(50);
describe alumnos;

drop table alumnos;



































