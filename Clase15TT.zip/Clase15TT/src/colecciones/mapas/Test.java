package colecciones.mapas;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.TreeMap;

public class Test {
    public static void main(String[] args) {
//        HashMap<String,String> mapa = new HashMap<>();
//        LinkedHashMap<String,String> mapa = new LinkedHashMap<>();
        TreeMap<String,String> mapa = new TreeMap<>();
        
        mapa.put("rojo", "red");
        mapa.put("verde", "green");
        mapa.put("azul", "blue");
        mapa.put("blanco", "white");
        mapa.put("negro", "black");
        mapa.put("naranja", "orange");
        
        //diccionario completo
        System.out.println(mapa);
        
        System.out.println("Claves del diccionario: " + mapa.keySet());
        
        System.out.println("Valores del diccionario: " + mapa.values());
        
        System.out.println("valor de la clave verde: " + mapa.get("verde"));
        
        System.out.println("valor de una clave inexistente: " + mapa.getOrDefault("gris","color no traducido"));
    }
}






