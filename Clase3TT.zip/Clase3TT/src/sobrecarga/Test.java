package sobrecarga;

public class Test {
    public static void main(String[] args) {
        //creo un auto
        Auto a = new Auto();
        
        //le doy un estado inicial
        a.marca = "Ford";
        a.velocidad = 0;
        
        //comportamiento
        a.acelerar();//0 -> 10
        a.acelerar(25);//10 -> 35
        a.acelerar(10, false);//35 -> 45
        a.acelerar(20, true);//45 -> 85
        
        //muestro el estado final
        System.out.println(a);
    }
}
