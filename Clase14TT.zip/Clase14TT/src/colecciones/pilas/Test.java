package colecciones.pilas;

import java.util.Stack;

public class Test {
    public static void main(String[] args) {
        //creo una coleccion de tipo Pila (LIFO) --> Stack
        Stack pila = new Stack();
        
        //agrego objetos a la coleccion
        pila.push("Juan");
        pila.push("Maria");
        pila.push("Luis");
        pila.push("Carlos");
        
        //muestro el contenido
        System.out.println("Contenido" + pila);
        
        System.out.println("Tamaño: " + pila.size());
        
        System.out.println("1er objeto que deberia salir: " + pila.peek());
        
        System.out.println("saco un objeto: " + pila.pop());
        
        System.out.println("Nuevo contenido: " + pila);
        
        pila.remove("Luis");
        
        System.out.println("Nuevo contenido: " + pila);
        
        System.out.println("Pila vacia?: " + pila.empty());
        
        
    }
}
