package relaciones1a1;

public class Test {
    public static void main(String[] args) {
        Motor m = new Motor(1600);
        Auto a = new Auto("Ford", m);
        
        System.out.println("Motor: " + m);
        System.out.println("Auto: " + a);
        
    }
}
