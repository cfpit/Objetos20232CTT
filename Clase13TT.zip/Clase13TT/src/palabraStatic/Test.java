package palabraStatic;

public class Test {
    public static void main(String[] args) {
        System.out.println("Velocidad minima de todos los autos");
        System.out.println(Auto.velMin + " Km./h.");
        
        Auto a = new Auto();
        Auto b = new Auto();
        Auto c = new Auto();
        
        System.out.println("Velocidad minima auto a=  " +a.velMin);
        System.out.println("Velocidad minima auto b=  " +b.velMin);
        System.out.println("Velocidad minima auto c=  " +c.velMin);
        
        //llamo al garbage collector
        System.gc();
        
    }
}
