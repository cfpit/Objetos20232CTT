package excepciones.ckecked;

public class Test {
    public static void main(String[] args) throws NoHayMasPasajesException {
        Vuelo v = new Vuelo("ABC-123", 100);
        
        try {
            v.venderPasajes(25);
            v.venderPasajes(10);
            v.venderPasajes(2);
            v.venderPasajes(45);
            v.venderPasajes(10);
            v.venderPasajes(20);//esta linea lanza excepcion
        } catch (NoHayMasPasajesException e) {
            e.mostrarMensaje();
        } finally{
            //medidas para no caer en excepcion otra vez
            //por ej: desconectarse de BD
        }
        
        System.out.println(v);
    }
}
