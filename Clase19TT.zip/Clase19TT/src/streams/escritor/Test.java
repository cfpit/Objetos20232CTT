package streams.escritor;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Test {
    public static void main(String[] args) throws IOException {
        //creo un objeto File q contiene la ruta del archivo a escribir
        File archivo = new File("src\\streams\\escritor\\archivo.txt");
        
        //creo el stream de escritura
           //modo escritura
//        BufferedWriter escritor = new BufferedWriter(new FileWriter(archivo));
        
        //modo agregado --> append
        BufferedWriter escritor = new BufferedWriter(new FileWriter(archivo,true));
        
        //preparamos el contenido a escribir en el archivo a traves del stream
        String linea1 = "Esta es la linea #1";
        String linea2 = "Esta es la linea #2";
        String linea3 = "Esta es la linea #3";
        
        //si el archivo no existe, el stream lo crea y escribe dentro de el.
        //si el archivo existe, el stream lo sobrescribe.
        escritor.write(linea1, 0, linea1.length());
        escritor.newLine();
        escritor.write(linea2);
        escritor.newLine();
        escritor.write(linea3, 5, 10);
        escritor.newLine();
        
        //agrego contenido al archivo
        escritor.append("Esto es lo que agrego");
        
        //cierro el stream
        escritor.close();
        
    }
}
