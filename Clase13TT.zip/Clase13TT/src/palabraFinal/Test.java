package palabraFinal;

public class Test {
    public static void main(String[] args) {
        Auto a = new Auto("Ford", 0);
        
        
//        a.VELMAX = 300;

        System.out.println("velocidad maxima= " + a.VELMAX + " Km./h." );
    }
}
