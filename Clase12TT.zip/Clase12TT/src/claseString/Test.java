package claseString;

import java.util.Arrays;

public class Test {
    public static void main(String[] args) {
//        String frase = "Curso,de,Java";
        String frase = "Curso de Java";
        
        System.out.println("Longitud: " + frase.length() + " caracteres");
        
        System.out.println("toUpperCase: " + frase.toUpperCase());
        
        System.out.println("toLowerCase: " + frase.toLowerCase());
        
        System.out.println("substring: " + frase.substring(0, 5));//Curso
        
//        csv --> juan,perez,Medrano 162,CABA

        String [] a = new String[3];
        
//        a = frase.split(",");
        a = frase.split(" ");
        System.out.println(Arrays.toString(a));//[Curso,de,Java]
        System.out.println("Palabra en la posicion 0: " + a[0]);//Curso
        
        System.out.println("replace: " + frase.replace('a', 'x'));//Curso de Jxvx
        
        System.out.println("1er caracter con charAt: " + frase.charAt(0));//C
        
        
        
        
        
    }
}
