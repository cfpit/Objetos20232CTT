package palabraFinal;

public class AutoCarrera extends Auto{


//    public  void setVelocidad(int velocidad) {
//        this.velocidad = velocidad;
//    }
}
    