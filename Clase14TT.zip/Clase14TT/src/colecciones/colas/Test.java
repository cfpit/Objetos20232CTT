package colecciones.colas;

import java.util.LinkedList;
import java.util.Queue;

public class Test {
    public static void main(String[] args) {
        //creo una coleccion de tipo cola(FIFO)-> queue
        Queue cola = new LinkedList();
        
        //agrego objetos a la coleccion
        cola.add("Juan");
        cola.add("Maria");
        cola.add("Luis");
        cola.add("Carlos");
        
        //muestro el contenido
        System.out.println("Contenido" + cola);
        
        System.out.println("Tamaño: " + cola.size());
        
        System.out.println("1er objeto que deberia salir: " + cola.peek());
        
        System.out.println("saco un objeto: " + cola.poll());
        
        System.out.println("Nuevo contenido: " + cola);
        
        cola.remove("Luis");
        
        System.out.println("Nuevo contenido: " + cola);
        
        
        
        
        
        
        
    }
}
