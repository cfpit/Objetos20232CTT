package excepciones.unchecked;

public class Test {
    public static void main(String[] args) {
        
        try {
            String palabra = "Hola";
            System.out.println("Longitud: " + palabra.length());
            
            String palabra2 = null;
            System.out.println("Longitud: " + palabra2.length());
        } catch (Exception e) {
            System.out.println("Error de puntero a nulo");
        }
        
        System.out.println("Continuando con la ejecucion de la app");
    }
}
