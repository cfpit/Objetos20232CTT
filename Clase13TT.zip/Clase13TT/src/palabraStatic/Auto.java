package palabraStatic;

public class Auto {
    
    private String marca;
    private int velocidad;
    public static int velMin = 0;//atributo de clase

    public Auto() {}

    public Auto(String marca, int velocidad) {
        this.setMarca(marca);
        this.setVelocidad(velocidad);
    }
    
    
    public int getVelocidad() {
        return velocidad;
    }

    public final void setVelocidad(int velocidad) {
        this.velocidad = velocidad;
    }


    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    @Override
    public String toString() {
        return "Auto{" + "marca=" + marca + ", velocidad=" + velocidad + '}';
    }
}
