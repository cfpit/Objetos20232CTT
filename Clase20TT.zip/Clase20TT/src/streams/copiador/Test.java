package streams.copiador;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Test {
    public static void main(String[] args) throws FileNotFoundException, IOException {
//        File archivoOrigen = new File("src\\streams\\copiador\\origen.txt");
        try {
            File archivoOrigen = new File("src/streams/copiador/origen.txt");
            File archivoDestino = new File("src/streams/copiador/destino.txt");

            //creo los streams de lectura y escritura para la copia
            BufferedReader lector = new BufferedReader(new FileReader(archivoOrigen));
            BufferedWriter escritor = new BufferedWriter(new FileWriter(archivoDestino));

            //bucle de copia
            String unaLinea;
            
            while ((unaLinea = lector.readLine()) != null) {
                escritor.write(unaLinea);
                escritor.newLine();
            }

            //cierro los streams
            lector.close();
            escritor.close();
            
            System.out.println("Archivo copiado");
        } catch (FileNotFoundException e) {
            System.out.println("Archivo no encontrado");
        } catch (IOException e) {
            System.out.println("Archivo corrupto");
        } catch (Exception e) {
            System.out.println("Error");
        }
        
        
    }
}
