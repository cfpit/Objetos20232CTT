

package base3;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;


public class Alumno {
    private String nombre;
    private int edad;

    public Alumno() {}

    public Alumno(String nombre, int edad) {
        this.setNombre(nombre);
        this.setEdad(edad);
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    @Override
    public String toString() {
        return nombre + " - " + edad + " años";
    }
    
    public static void consultarTodos() throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        Connection unaConexion = Conexion.obtenerConexion();
        
        String unaConsulta = "select * from alumnos";
        
        Statement unaSentencia = unaConexion.createStatement();
        
        ResultSet unResultado = unaSentencia.executeQuery(unaConsulta);
        
        while (unResultado.next()) {            
            System.out.println("Nombre: " + unResultado.getString("nombre"));
            System.out.println("Edad: " + unResultado.getInt("edad"));
            System.out.println("--------------------------------");
        }
        
        unaConexion.close();
        unaSentencia.close();
        unResultado.close();
    }
    
    
    public static void consultarUno(String nombre) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        Connection unaConexion = Conexion.obtenerConexion();
        
        String unaConsulta = "select * from alumnos where nombre = '" + nombre + "'";
        
        Statement unaSentencia = unaConexion.createStatement();
        
        ResultSet unResultado = unaSentencia.executeQuery(unaConsulta);
        
        if (unResultado.next()) {            
            System.out.println("Nombre: " + unResultado.getString("nombre"));
            System.out.println("Edad: " + unResultado.getInt("edad"));
            System.out.println("--------------------------------");
        }
        
        unaConexion.close();
        unaSentencia.close();
        unResultado.close();
    }
    
    
    public static void insertar(Alumno a) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        Connection unaConexion = Conexion.obtenerConexion();
        
        String unaInsercion = "insert into alumnos(nombre,edad) values(?, ?)";
        
        PreparedStatement unaSentencia = unaConexion.prepareStatement(unaInsercion);
        
        unaSentencia.setString(1, a.getNombre());
        unaSentencia.setInt(2, a.getEdad());
        
        unaSentencia.execute();
        
        System.out.println("Insercion correcta");
        
        unaConexion.close();
        unaSentencia.close();
        
    }
    
    
    public static void actualizar(String nombreAnterior, String nombreNuevo) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        Connection unaConexion = Conexion.obtenerConexion();
        
        String unaActualizacion = "update alumnos set nombre = ? where nombre = ?";
        
        PreparedStatement unaSentencia = unaConexion.prepareStatement(unaActualizacion);
        
        unaSentencia.setString(1, nombreNuevo);
        unaSentencia.setString(2, nombreAnterior);
        
        unaSentencia.execute();
        
        System.out.println("Actualizacion correcta");
        
        unaConexion.close();
        unaSentencia.close();
        
    }
    
    
    public static void eliminar(String nombre) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        Connection unaConexion = Conexion.obtenerConexion();
        
        String unaEliminacion = "delete from alumnos where nombre = ?";
        
        PreparedStatement unaSentencia = unaConexion.prepareStatement(unaEliminacion);
        
        unaSentencia.setString(1, nombre);
        
        unaSentencia.execute();
        
        System.out.println("Eliminacion correcta");
        
        unaConexion.close();
        unaSentencia.close();
        
    }
    
    
    public static ArrayList cargarLista() throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        ArrayList <Alumno> lista = new ArrayList<Alumno>();
        
        Connection unaConexion = Conexion.obtenerConexion();
        
        String unaConsulta = "select * from alumnos";
        
        Statement unaSentencia = unaConexion.createStatement();
        
        ResultSet unResultado = unaSentencia.executeQuery(unaConsulta);
        
        while (unResultado.next()) {            
            String nombre = unResultado.getString("nombre");
            int edad = unResultado.getInt("edad");
            
            Alumno a = new Alumno(nombre, edad);
            lista.add(a);
        }
        
        unaConexion.close();
        unaSentencia.close();
        unResultado.close();
        
        return lista;
    }
}
