package base;

import java.sql.SQLException;
import java.util.Scanner;

public class Test {
    public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
//        System.out.println("Consultar Todos");
//        Alumno.consultarTodos();
//        Alumno.consultarUno("Juan");


//        System.out.println("Insercion");
//        Scanner lector = new Scanner(System.in);
//        
//        System.out.println("Ingresa tu nombre: ");
//        String nombre = lector.next();
//        
//        System.out.println("Ingresa tu edad: ");
//        int edad = lector.nextInt();
//        
//        Alumno a = new Alumno(nombre, edad);
//        
//        Alumno.insercion(a);
        
        
//        System.out.println("Eliminacion");
//        Scanner lector = new Scanner(System.in);
//        
//        System.out.println("Ingresa tu nombre del alumno a eliminar: ");
//        String nombre = lector.next();
//        
//        Alumno.eliminacion(nombre);

        System.out.println("Actualizacion");
        Scanner lector = new Scanner(System.in);
        
        System.out.println("Ingresa el nombre del alumno que queres cambiar: ");
        String nombreAnterior = lector.next();
        
        System.out.println("Ingresa el nuevo nombre: ");
        String nombreNuevo = lector.next();
        
        Alumno.actualizacion(nombreAnterior, nombreNuevo);
        
        
        
    }
}
